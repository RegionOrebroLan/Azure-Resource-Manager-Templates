﻿configuration Chrome
{
	Import-DscResource -Module PSDesiredStateConfiguration, xChrome;

	MSFT_xChrome "Chrome"
	{
		Language = "en";
		LocalPath = "$($env:Temp)\GoogleChromeStandaloneEnterprise.msi";
	}

	# And we should add a chrome-shortcut to the activity-field.
	# C:\Users\Default\AppData\Roaming\Microsoft\Internet Explorer\Quick Launch\User Pinned\TaskBar
	# https://stackoverflow.com/questions/9739772/how-to-pin-to-taskbar-using-powershell
}