﻿configuration MachineConfiguration
{
	param
	(
		[Parameter(Mandatory)]
		[PSCredential]$credential,
		[Parameter(Mandatory)]
		[string]$domainName
	)

	Import-DscResource -Module Parts, PSDesiredStateConfiguration, xActiveDirectory;

	node localhost
	{
		LocalConfigurationManager
		{
			RebootNodeIfNeeded = $true;
		}
	
		WindowsFeature "ActiveDirectoryDomainServicesFeature"
		{
			Ensure = "Present";
			Name = "AD-Domain-Services";
		}

		WindowsFeature "ActiveDirectoryDomainServicesToolsFeature"
		{
			Ensure = "Present";
			Name = "RSAT-ADDS-Tools";
			DependsOn = "[WindowsFeature]ActiveDirectoryDomainServicesFeature";
		}

		WindowsFeature "ActiveDirectoryAdministrationCenterFeature"
		{
			Ensure = "Present";
			Name = "RSAT-AD-AdminCenter";
			DependsOn = "[WindowsFeature]ActiveDirectoryDomainServicesFeature";
		}

		xADDomain "ActiveDirectoryDomain"
		{
			DomainAdministratorCredential = $credential;
			DomainName = $domainName;
			SafemodeAdministratorPassword = $credential;
			DependsOn = "[WindowsFeature]ActiveDirectoryDomainServicesFeature";
		}

		Chrome Chrome {}
	}
}