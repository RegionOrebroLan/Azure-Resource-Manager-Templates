﻿configuration CertificateTrust
{
	param
	(
		[string[]]$certificateNames,
		[Parameter(Mandatory)]
		[PSCredential]$credential,
		[Parameter(Mandatory)]
		[string]$domainControllerName
	)

	Import-DscResource -Module PSDesiredStateConfiguration;

	$_certificatesDirectoryPath = "\\$($domainControllerName)\Domain-Files\Certificates\";
	$_certificateStoreLocation = "Cert:\LocalMachine\Root\";
	$_existsPrefix = "Exists=True;Result=";
	
	if($certificateNames)
	{
		foreach($certificateName in $certificateNames)
		{
			Script "$($certificateName)-Trust"
			{
				GetScript = {
					$path = "$($using:_certificatesDirectoryPath)$($using:certificateName).pfx";
					$result = $path;

					try
					{
						$certificateData = Get-PfxData -ErrorAction SilentlyContinue -FilePath $path -Password $using:credential.Password;

						$certificate = Get-Item "$($using:_certificateStoreLocation)$($certificateData.EndEntityCertificates[0].Thumbprint)" -ErrorAction SilentlyContinue;
					}
					catch
					{
						$certificate = $null;
					}

					if($certificate)
					{
						$result = "$($using:_existsPrefix)$($result)";
					}

					return @{ Result = $result };
				}
				SetScript = {
					try
					{
						$certificateStoreLocation = "Cert:\LocalMachine\My\";
						$path = (Invoke-Expression -Command $GetScript)["Result"];
						
						$certificate = Import-PfxCertificate -CertStoreLocation $certificateStoreLocation -FilePath $path -Password $using:credential.Password;

						$certificateStoreLocation = $using:_certificateStoreLocation;
						$path = "$($env:TEMP)\$($using:certificateName).cer";

						Export-Certificate -Cert $certificate -FilePath $path;

						Import-Certificate -CertStoreLocation $certificateStoreLocation -FilePath $path;

						Remove-Item -Path $certificate.PSPath;

						Remove-Item -Path $path;
					}
					catch
					{
						throw "Could not import certificate ""$($path)"" to ""$($certificateStoreLocation)"". -> $($_.Exception.Message)";
					}
				}
				TestScript = {
					$result = (Invoke-Expression -Command $GetScript)["Result"];

					if($result -and $result.StartsWith($using:_existsPrefix))
					{
						return $true;
					}

					return $false;
				}
			}
		}
	}
}