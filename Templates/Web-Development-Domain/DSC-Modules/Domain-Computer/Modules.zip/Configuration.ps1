﻿configuration DomainComputerConfiguration
{
	param
	(
		[Parameter(Mandatory)]
		[PSCredential]$credential,
		[Parameter(Mandatory)]
		[string]$domainControllerName,
		[Parameter(Mandatory)]
		[string]$domainName
	)

	$executionPolicy = Get-ExecutionPolicy -Scope LocalMachine;

	if($executionPolicy -ne "RemoteSigned")
	{
		Set-ExecutionPolicy RemoteSigned -Force -Scope LocalMachine;
	}

	Import-DscResource -Module Parts, PSDesiredStateConfiguration;

	node localhost
	{
		<#
		LocalConfigurationManager
		{
			RebootNodeIfNeeded = $true;
		}
		#>
	
		<#
		DomainComputer DomainComputer
		{
			Credential = $credential;
			DomainName = $domainName;
		}
		#>

		Sharing Sharing {}

		CertificateTrust CertificateTrust
		{
			CertificateNames = "Application-Gateway-Authentication-Certificate", "Application-Gateway-SSL-Certificate";
			Credential = $credential;
			DomainControllerName = $domainControllerName;
		}
	
		Chrome Chrome {}
	}
}