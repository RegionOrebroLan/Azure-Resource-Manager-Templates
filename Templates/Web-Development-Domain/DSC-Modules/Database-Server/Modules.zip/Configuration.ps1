﻿configuration DatabaseServerConfiguration
{
	param
	(
		[Parameter(Mandatory)]
		[PSCredential]$credential,
		[Parameter(Mandatory)]
		[string]$domainControllerName,
		[Parameter(Mandatory)]
		[string]$domainName
	)

	Import-DscResource -Module Parts, PSDesiredStateConfiguration;

	$_existsPrefix = "Exists=True;Result=";

	node localhost
	{
		LocalConfigurationManager
		{
			RebootNodeIfNeeded = $true;
		}
		
		DomainComputer DomainComputer
		{
			Credential = $credential;
			DomainName = $domainName;
		}
			
		# If we need to change collation for the SQL-server we can find a way to do it here. When this DSC-configuration is triggered the SQL-Server is already installed.
		# A way to do it: https://www.mssqltips.com/sqlservertip/3519/changing-sql-server-collation-after-installation/
		# sqlservr -m -T4022 -T3659 -s"SQLEXP2014" -q"SQL_Latin1_General_CP1_CI_AI"

		Script DomainAdministratorsAccess
		{
			GetScript = {
				$domainShortName = ($using:credential).UserName.Split("\")[0];

				$domainAdministratorsLogin = "$($domainShortName)\Domain Admins";

				Import-Module SqlPS;

				#$sqlServer = New-Object Microsoft.SqlServer.Management.Smo.Server -ArgumentList $env:ComputerName;
				$sqlServer = New-Object Microsoft.SqlServer.Management.Smo.Server;

				foreach($login in $sqlServer.Logins)
				{
					if($login.Name.ToUpper() -eq $domainAdministratorsLogin.ToUpper())
					{
						Remove-Module SqlPS;

						return @{ Result = "$($using:_existsPrefix)$($domainAdministratorsLogin)" };
					}
				}

				Remove-Module SqlPS;

				return @{ Result = $domainAdministratorsLogin };
			}
			SetScript = {
				try
				{
					$domainAdministratorsLogin = (Invoke-Expression -Command $GetScript)["Result"];

					Import-Module SqlPS;

					#$sqlServer = New-Object Microsoft.SqlServer.Management.Smo.Server -ArgumentList $env:ComputerName;
					$sqlServer = New-Object Microsoft.SqlServer.Management.Smo.Server;

					$login = New-Object Microsoft.SqlServer.Management.Smo.Login -ArgumentList $sqlServer, $domainAdministratorsLogin;
					$login.LoginType = "WindowsUser";
					$login.Create();

					$login.AddToRole("sysadmin");
					$login.Alter();

					Remove-Module SqlPS;
				}
				catch
				{
					throw "Could not create SQL-Server login, domain-administrator-login = ""$($domainAdministratorsLogin)"". -> $($_.Exception.Message)";
				}
			}
			TestScript = {
				$result = (Invoke-Expression -Command $GetScript)["Result"];

				if($result -and $result.StartsWith($using:_existsPrefix))
				{
					return $true;
				}

				return $false;
			}
		}

		CertificateTrust CertificateTrust
		{
			CertificateNames = "Application-Gateway-Authentication-Certificate", "Application-Gateway-SSL-Certificate";
			Credential = $credential;
			DomainControllerName = $domainControllerName;
		}

		Chrome Chrome {}
	}
}