﻿configuration WebServer
{
	Import-DscResource -Module PSDesiredStateConfiguration;

	WindowsFeature "WebServerFeature"
	{
		Ensure = "Present";
		Name = "Web-Server";
	}

	WindowsFeature "WebSecurityFeature"
	{
		Ensure = "Present";
		IncludeAllSubFeature = $true;
		Name = "Web-Security";
	}

	WindowsFeature "WebAppDevFeature"
	{
		Ensure = "Present";
		IncludeAllSubFeature = $true;
		Name = "Web-App-Dev";
	}

	<#
	WindowsFeature "AspDotNet45Feature"
	{
		Ensure = "Present";
		Name = "Web-Asp-Net45";
	}
	#>

	WindowsFeature "WebServerManagementConsoleFeature"
	{
		Ensure = "Present";
		Name = "Web-Mgmt-Console";
	}
}