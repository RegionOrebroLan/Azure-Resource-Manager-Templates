﻿configuration WebServer
{
	Import-DscResource -Module PSDesiredStateConfiguration;

	$_existsPrefix = "Exists=True;Result=";

	WindowsFeature "WebServerFeature"
	{
		Ensure = "Present";
		Name = "Web-Server";
	}

	WindowsFeature "WebSecurityFeature"
	{
		Ensure = "Present";
		IncludeAllSubFeature = $true;
		Name = "Web-Security";
	}

	WindowsFeature "WebAppDevFeature"
	{
		Ensure = "Present";
		IncludeAllSubFeature = $true;
		Name = "Web-App-Dev";
	}

	<#
	WindowsFeature "AspDotNet45Feature"
	{
		Ensure = "Present";
		Name = "Web-Asp-Net45";
	}
	#>

	WindowsFeature "WebServerManagementConsoleFeature"
	{
		Ensure = "Present";
		Name = "Web-Mgmt-Console";
	}

	Script "ASP-NET-Core-Module"
	{
		GetScript = {
			# https://aka.ms/dotnetcore-2-windowshosting/
			$result = "https://download.microsoft.com/download/5/C/1/5C190037-632B-443D-842D-39085F02E1E8/DotNetCore.2.0.3-WindowsHosting.exe";

			$aspNetCoreModule = Get-WebGlobalModule -Name "AspNetCoreModule";

			if($aspNetCoreModule)
			{
				$result = "$($using:_existsPrefix)$($result)";
			}

			return @{ Result = $result };
		}
		SetScript = {
			$result = (Invoke-Expression -Command $GetScript)["Result"];
			$path = "$($env:temp)\DotNetCore.2.0.3-WindowsHosting.exe";

			Invoke-WebRequest $result -OutFile $path;
			Start-Process $path -ArgumentList "/quiet" -Wait;

			# Restart the IIS so that system-path updates take effect.
			net stop was /y;
			net start w3svc;
		}
		TestScript = {
			$result = (Invoke-Expression -Command $GetScript)["Result"];

			if($result -and $result.StartsWith($using:_existsPrefix))
			{
				return $true;
			}

			return $false;
		}
		DependsOn = "[WindowsFeature]WebServerFeature";
	}
}