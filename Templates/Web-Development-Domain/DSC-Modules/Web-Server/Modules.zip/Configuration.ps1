﻿configuration WebServerConfiguration
{
	param
	(
		[Parameter(Mandatory)]
		[PSCredential]$credential,
		[Parameter(Mandatory)]
		[string]$defaultHtmlUrl,
		[Parameter(Mandatory)]
		[string]$domainControllerName,
		[Parameter(Mandatory)]
		[string]$domainName,
		[Parameter(Mandatory)]
		[string]$webConfigUrl
	)

	Import-DscResource -Module Parts, PSDesiredStateConfiguration;

	$_certificateStoreLocation = "CERT:\LocalMachine\My\";
	$_existsPrefix = "Exists=True;Result=";
	$_exportedHttpsWebBindingCertificatePath = "\\$($domainControllerName)\Domain-Files\Certificates\Application-Gateway-Authentication-Certificate.pfx";
	$_httpsWebBindingName = "Default Web Site";
	$_httpsWebBindingProtocol = "https";
	$_wwwRootDirectoryPath = "C:\Inetpub\WwwRoot\";

	node localhost
	{
		LocalConfigurationManager
		{
			RebootNodeIfNeeded = $true;
		}
		
		DomainComputer DomainComputer
		{
			Credential = $credential;
			DomainName = $domainName;
		}

		WebServer WebServer {}

		Script DefaultHtml
		{
			GetScript = {
				$defaultHtmlPath = "$($using:_wwwRootDirectoryPath)Default.html";
				$result = $defaultHtmlPath;

				if(Test-Path $defaultHtmlPath)
				{
					$result = "$($using:_existsPrefix)$($result)";
				}

				return @{ Result = $result };
			}
			SetScript = {
				$defaultHtmlPath = (Invoke-Expression -Command $GetScript)["Result"];

				Invoke-WebRequest $using:defaultHtmlUrl -OutFile $defaultHtmlPath;
			}
			TestScript = {
				$result = (Invoke-Expression -Command $GetScript)["Result"];

				if($result -and $result.StartsWith($using:_existsPrefix))
				{
					return $true;
				}

				return $false;
			}
			DependsOn = "[WebServer]WebServer";
		}

		Script WebConfig
		{
			GetScript = {
				$webConfigPath = "$($using:_wwwRootDirectoryPath)Web.config";
				$result = $webConfigPath;

				if(Test-Path $webConfigPath)
				{
					$result = "$($using:_existsPrefix)$($result)";
				}

				return @{ Result = $result };
			}
			SetScript = {
				$webConfigPath = (Invoke-Expression -Command $GetScript)["Result"];

				Invoke-WebRequest $using:webConfigUrl -OutFile $webConfigPath;
			}
			TestScript = {
				$result = (Invoke-Expression -Command $GetScript)["Result"];

				if($result -and $result.StartsWith($using:_existsPrefix))
				{
					return $true;
				}

				return $false;
			}
			DependsOn = "[WebServer]WebServer";
		}

		Script HttpsWebBindingCertificate
		{
			GetScript = {
				$result = $using:_exportedHttpsWebBindingCertificatePath;
				
				$thumbprint = (Get-PfxData -FilePath $using:_exportedHttpsWebBindingCertificatePath -Password $using:credential.Password).EndEntityCertificates[0].Thumbprint;
				$certificatePath = "$($using:_certificateStoreLocation)$($thumbprint)";

				$certificate = Get-Item -ErrorAction SilentlyContinue -Path $certificatePath;

				if($certificate)
				{
					$result = "$($using:_existsPrefix)$($result)";
				}

				return @{ Result = $result };
			}
			SetScript = {
				$exportedCertificatePath = (Invoke-Expression -Command $GetScript)["Result"];

				Import-PfxCertificate -CertStoreLocation $using:_certificateStoreLocation -FilePath $exportedCertificatePath -Password $using:credential.Password;
			}
			TestScript = {
				$result = (Invoke-Expression -Command $GetScript)["Result"];

				if($result -and $result.StartsWith($using:_existsPrefix))
				{
					return $true;
				}

				return $false;
			}
			DependsOn = "[WebServer]WebServer";
		}

		Script HttpsWebBinding
		{
			GetScript = {
				$result = "$($using:_httpsWebBindingName);$($using:_httpsWebBindingProtocol)";

				$httpsWebBinding = Get-WebBinding -ErrorAction SilentlyContinue -Name $using:_httpsWebBindingName -Protocol $using:_httpsWebBindingProtocol;

				if($httpsWebBinding -and $httpsWebBinding.sslFlags -eq 1)
				{
					$result = "$($using:_existsPrefix)$($result)";
				}

				return @{ Result = $result };
			}
			SetScript = {
				$httpsWebBinding = Get-WebBinding -ErrorAction SilentlyContinue -Name $using:_httpsWebBindingName -Protocol $using:_httpsWebBindingProtocol;

				if(!$httpsWebBinding)
				{
					$httpsWebBinding = New-WebBinding -Name $using:_httpsWebBindingName -Protocol $using:_httpsWebBindingProtocol;
				}

				if($httpsWebBinding.sslFlags -ne 1)
				{
					$thumbprint = (Get-PfxData -FilePath $using:_exportedHttpsWebBindingCertificatePath -Password $using:credential.Password).EndEntityCertificates[0].Thumbprint;
					$certificatePath = "$($using:_certificateStoreLocation)$($thumbprint)";
					$certificate = Get-Item -Path $certificatePath;

					$httpsWebBinding.AddSslCertificate($certificate.GetCertHashString(), "My");

					$httpsWebBinding.sslFlags = 1;
				}
			}
			TestScript = {
				$result = (Invoke-Expression -Command $GetScript)["Result"];

				if($result -and $result.StartsWith($using:_existsPrefix))
				{
					return $true;
				}

				return $false;
			}
			DependsOn = "[Script]HttpsWebBindingCertificate";
		}

		CertificateTrust CertificateTrust
		{
			CertificateNames = "Application-Gateway-Authentication-Certificate", "Application-Gateway-SSL-Certificate";
			Credential = $credential;
			DomainControllerName = $domainControllerName;
		}

		Chrome Chrome {}
	}
}