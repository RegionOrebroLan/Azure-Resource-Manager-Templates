﻿configuration DomainControllerConfiguration
{
	param
	(
		[string]$adfsCertificateTemplateNames = "SslCertificateTemplate;SSL Certificate Template",
		[Parameter(Mandatory)]
		[string]$applicationGatewayAuthenticationCertificateValue,
		[Parameter(Mandatory)]
		[string]$applicationGatewaySslCertificateValue,
		[Parameter(Mandatory)]
		[PSCredential]$credential,
		[object[]]$dnsRecords,
		[Parameter(Mandatory)]
		[string]$dnsServerForwarderIpAddress,
		[Parameter(Mandatory)]
		[string]$dnsServerIpAddress,
		[Parameter(Mandatory)]
		[string]$domainName,
		[Parameter(Mandatory)]
		[string]$ipAddress,
		[object[]]$serviceAccounts
	)

	Import-DscResource -Module Parts, PSDesiredStateConfiguration;

	$adfsCertificateTemplateNamesParts = $adfsCertificateTemplateNames.Split(";");
	$adfsCertificateTemplateName = $adfsCertificateTemplateNamesParts[0];
	$adfsCertificateTemplateDisplayName = $adfsCertificateTemplateNamesParts[1];
	$_adfsCertificateTemplateAdminDisplayName = "ADFS-Certificate-Template";
	$_adfsCertificateTemplateAdminDisplayNameAttributeName = "adminDisplayName";
	$_certificateTemplatesContainerRelativePath = "CN=Certificate Templates,CN=Public Key Services,CN=Services";
	$_domainCertificatesDirectoryName = "Certificates";
	$_domainFilesDirectoryName = "Domain-Files";
	$_domainFilesDirectoryPath = "C:\$($_domainFilesDirectoryName)\";
	$_existsPrefix = "Exists=True;Result=";
	$_ldapPathPrefix = "LDAP://";
	$_rootDsePath = "$($_ldapPathPrefix)RootDSE";

	node localhost
	{
		LocalConfigurationManager
		{
			RebootNodeIfNeeded = $true;
		}
	
		DomainController DomainController
		{
			Credential = $credential;
			DnsServerForwarderIpAddress = $dnsServerForwarderIpAddress;
			DnsServerIpAddress = $dnsServerIpAddress;
			DomainName = $domainName;
			IpAddress = $ipAddress;
		}
		
		CertificateServer CertificateServer
		{
			Credential = $credential;
			DependsOn = "[DomainController]DomainController";
		}
		
		if($dnsRecords)
		{
			foreach($dnsRecord in $dnsRecords)
			{
				DomainNameRecord "DomainNameRecord-$($dnsRecord.Name)"
				{
					DomainName = $domainName;
					IpAddress = $dnsRecord.IpAddress;
					Name = $dnsRecord.Name;
					DependsOn = "[DomainController]DomainController";
				}
			}
		}

		# This script configures a certificate template to use for ADFS. See the steps under "Configure a template", https://technet.microsoft.com/en-us/library/dn781428(v=ws.11).aspx.
		# Got help here: Duplicate certificate template, edit and publish it - https://social.technet.microsoft.com/Forums/windows/en-US/347acc93-8352-4535-ab1a-23ebd49eea22/duplicate-certificate-template-edit-and-publish-it/
		Script AdfsCertificateTemplate
		{
			GetScript = {
				$certificateTemplatesContainerPath = "$($using:_ldapPathPrefix)$($using:_certificateTemplatesContainerRelativePath),$(([ADSI]$using:_rootDsePath).ConfigurationNamingContext.Value)";
				$result = $certificateTemplatesContainerPath;

				$certificateTemplatesContainer = [ADSI]$certificateTemplatesContainerPath;

				foreach($child in $certificateTemplatesContainer.Children)
				{
					if($child.Properties[$using:_adfsCertificateTemplateAdminDisplayNameAttributeName] -eq $using:_adfsCertificateTemplateAdminDisplayName)
					{
						$result = "$($using:_existsPrefix)$($child.Path)";

						break;
					}
				}

				return @{ Result = $result };
			}
			SetScript = {
				$result = (Invoke-Expression -Command $GetScript)["Result"];

				$certificateTemplatesContainer = [ADSI]$result;
				$certificateTemplateToCopy = [ADSI]"$($using:_ldapPathPrefix)CN=WebServer,$($certificateTemplatesContainer.DistinguishedName)";

				$certificateTemplate = $certificateTemplatesContainer.Create("pKICertificateTemplate", "CN=$($using:adfsCertificateTemplateName)");
				$certificateTemplate.Put($using:_adfsCertificateTemplateAdminDisplayNameAttributeName, $using:_adfsCertificateTemplateAdminDisplayName);
				$certificateTemplate.Put("displayName", $using:adfsCertificateTemplateDisplayName);
				$certificateTemplate.Put("flags", 131649);
				$certificateTemplate.Put("msPKI-Cert-Template-OID", "1.3.6.1.4.1.311.21.8.2729766.16688452.5915520.11002125.4785718.182.15114327.3254134");
				$certificateTemplate.Put("msPKI-Certificate-Application-Policy", "1.3.6.1.5.5.7.3.1");
				$certificateTemplate.Put("msPKI-Private-Key-Flag", 16842768);
				<#
				To know what values to enter for:
					- msPKI-Template-Minor-Revision
					- msPKI-Template-Schema-Version
					- revision
				look here: Obtain and Configure an SSL Certificate for AD FS, https://technet.microsoft.com/en-us/library/dn781428(v=ws.11).aspx
					- Obtain an SSL certificate from AD CS -> Configure a template, https://technet.microsoft.com/en-us/library/dn781428(v=ws.11).aspx#BKMK_1
					- Duplicate the "Web Server" template and look at the "Schema Version" and "Version" values
						- msPKI-Template-Minor-Revision = the minor version number in "Version", eg 100.2 gives 2. I guess 0 works here to.
						- msPKI-Template-Schema-Version = the "Schema Version" number
						- revision = the major version number in "Version", eg 100.2 gives 100
				#>
				$certificateTemplate.Put("msPKI-Template-Minor-Revision", "0");
				$certificateTemplate.Put("msPKI-Template-Schema-Version", "2");
				$certificateTemplate.Put("revision", "100");

				$propertyNamesToCopy = @("msPKI-Certificate-Name-Flag", "msPKI-Enrollment-Flag", "msPKI-Minimal-Key-Size", "msPKI-RA-Signature", "pKICriticalExtensions", "pKIDefaultCSPs", "pKIDefaultKeySpec", "pKIExpirationPeriod", "pKIExtendedKeyUsage", "pKIKeyUsage", "pKIMaxIssuingDepth", "pKIOverlapPeriod");

				foreach($propertyName in $propertyNamesToCopy)
				{
					$property = $certificateTemplateToCopy.Properties[$propertyName];
					$certificateTemplate.Put($propertyName, $property.Value);
				}

				$certificateTemplate.SetInfo();

				$accessAccounts = @("$($using:domainName)\Domain Computers", "$($using:domainName)\$($env:ComputerName)$");
				$accessType = "Allow";

				foreach($accessAccount in $accessAccounts)
				{
					$accessIdentifier = (New-Object System.Security.Principal.NTAccount($accessAccount)).Translate([System.Security.Principal.SecurityIdentifier]);
	
					foreach($accessRight in @("ReadProperty, GenericExecute"))
					{
						$accessRule = New-Object System.DirectoryServices.ActiveDirectoryAccessRule($accessIdentifier, $accessRight, $accessType);
						$certificateTemplate.ObjectSecurity.SetAccessRule($accessRule);
					}

					foreach($accessRight in @("ExtendedRight"))
					{
						# "Autoenroll" and "Enroll"
						foreach($accessGuid in @([Guid]"a05b8cc2-17bc-4802-a710-e7c15ab866a2", [Guid]"0e10c968-78fb-11d2-90d4-00c04f79dc55"))
						{
							$accessRule = New-Object System.DirectoryServices.ActiveDirectoryAccessRule($accessIdentifier, $accessRight, $accessType, $accessGuid);
							$certificateTemplate.ObjectSecurity.AddAccessRule($accessRule);
						}
					}
				}

				$certificateTemplate.CommitChanges();
			}
			TestScript = {
				$result = (Invoke-Expression -Command $GetScript)["Result"];

				if($result -and $result.StartsWith($using:_existsPrefix))
				{
					return $true;
				}

				return $false;
			}
			DependsOn = "[CertificateServer]CertificateServer";
		}

		# This script deploys the adfs-certificate-template to the CA. See the steps under "Assign a template to a CA", https://technet.microsoft.com/en-us/library/dn781428(v=ws.11).aspx.
		# Got help here: Complex Azure Template Odyssey Part Two: Domain Controller - https://blogs.blackmarble.co.uk/blogs/rhepworth/post/2015/08/30/Complex-Azure-Template-Odyssey-Part-Two-Domain-Controller#highlighter_296290
		# Line 50 and 51 in the function "Generate-NewCertificateTemplate".
		# We need the following PowerShell module: https://github.com/Crypt32/PSPKI
		Script AdfsCertificateTemplateDeployment
		{
			GetScript = {
				$name = $using:adfsCertificateTemplateName;
				$result = $name;
				
				foreach($template in Get-CATemplate)
				{
					if($template.Name -eq $name)
					{
						$result = "$($using:_existsPrefix)$($name)";

						break;
					}
				}

				return @{ Result = $result };
			}
			SetScript = {
				$name = (Invoke-Expression -Command $GetScript)["Result"];

				Import-Module PSPKI;

				$certificateTemplate = Get-CertificateTemplate -Name $name;
				Get-CertificationAuthority | Get-CATemplate | Add-CATemplate -Template $certificateTemplate | Set-CATemplate;

				Remove-Module PSPKI;
			}
			TestScript = {
				$result = (Invoke-Expression -Command $GetScript)["Result"];

				if($result -and $result.StartsWith($using:_existsPrefix))
				{
					return $true;
				}

				return $false;
			}
			DependsOn = "[Script]AdfsCertificateTemplate";
		}

		Script DomainFilesDirectory
		{
			GetScript = {
				$result = $using:_domainFilesDirectoryPath;

				if(Test-Path $using:_domainFilesDirectoryPath)
				{
					$result = "$($using:_existsPrefix)$($result)";
				}

				return @{ Result = $result };
			}
			SetScript = {
				$domainFilesDirectoryPath = (Invoke-Expression -Command $GetScript)["Result"];

				New-Item -ItemType Directory -Path $domainFilesDirectoryPath;
			}
			TestScript = {
				$result = (Invoke-Expression -Command $GetScript)["Result"];

				if($result -and $result.StartsWith($using:_existsPrefix))
				{
					return $true;
				}

				return $false;
			}
			DependsOn = "[DomainController]DomainController";
		}

		Script DomainFilesShare
		{
			GetScript = {
				$result = $using:_domainFilesDirectoryName;

				$domainFilesShare = Get-SmbShare -ErrorAction SilentlyContinue -Name $using:_domainFilesDirectoryName;

				if($domainFilesShare)
				{
					$result = "$($using:_existsPrefix)$($result)";
				}

				return @{ Result = $result };
			}
			SetScript = {
				$domainFilesDirectoryName = (Invoke-Expression -Command $GetScript)["Result"];

				#New-SmbShare –ContinuouslyAvailable $true –Name $domainFilesDirectoryName –Path $_domainFilesDirectoryPath;
				New-SmbShare –Name $domainFilesDirectoryName –Path $using:_domainFilesDirectoryPath;

				<#
					–FullAccess domain\admingroup
					-ChangeAccess domain\deptusers
					-ReadAccess domain\authenticated users
				#>
			}
			TestScript = {
				$result = (Invoke-Expression -Command $GetScript)["Result"];

				if($result -and $result.StartsWith($using:_existsPrefix))
				{
					return $true;
				}

				return $false;
			}
			DependsOn = "[Script]DomainFilesDirectory";
		}

		Script DomainCertificatesDirectory
		{
			GetScript = {
				$domainCertificatesDirectoryPath = "$($using:_domainFilesDirectoryPath)$($using:_domainCertificatesDirectoryName)";
				$result = $domainCertificatesDirectoryPath;

				if(Test-Path $domainCertificatesDirectoryPath)
				{
					$result = "$($using:_existsPrefix)$($result)";
				}

				return @{ Result = $result };
			}
			SetScript = {
				$domainCertificatesDirectoryPath = (Invoke-Expression -Command $GetScript)["Result"];

				New-Item -ItemType Directory -Path $domainCertificatesDirectoryPath;
			}
			TestScript = {
				$result = (Invoke-Expression -Command $GetScript)["Result"];

				if($result -and $result.StartsWith($using:_existsPrefix))
				{
					return $true;
				}

				return $false;
			}
			DependsOn = "[Script]DomainFilesShare";
		}

		Script AdfsCertificate
		{
			GetScript = {
				$exportedAdfsCertificatePath = "$($using:_domainFilesDirectoryPath)$($using:_domainCertificatesDirectoryName)\ADFS-Certificate.pfx";
				$result = $exportedAdfsCertificatePath;

				if(Test-Path $exportedAdfsCertificatePath)
				{
					$result = "$($using:_existsPrefix)$($result)";
				}

				return @{ Result = $result };
			}
			SetScript = {
				$exportedAdfsCertificatePath = (Invoke-Expression -Command $GetScript)["Result"];

				$dnsNames = New-Object System.Collections.Generic.List[string];
				$dnsNames.Add("adfs.$($using:domainName)");
				$dnsNames.Add("certauth.adfs.$($using:domainName)");
				$dnsNames.Add("enterpriseregistration.$($using:domainName)");

				$adfsCertificateEnrollmentResult = Get-Certificate -CertStoreLocation "CERT:\LocalMachine\My\" -DnsName $dnsNames -SubjectName "CN=$($dnsNames[0])" -Template $using:adfsCertificateTemplateName -Url "ldap:";

				$adfsCertificate = $adfsCertificateEnrollmentResult.Certificate;
				
				$exportedAdfsCertificate = Export-PfxCertificate -Cert $adfsCertificate -FilePath $exportedAdfsCertificatePath -Force -Password $using:credential.Password;

				Remove-Item -Path $adfsCertificate.PSPath;
			}
			TestScript = {
				$result = (Invoke-Expression -Command $GetScript)["Result"];

				if($result -and $result.StartsWith($using:_existsPrefix))
				{
					return $true;
				}

				return $false;
			}
			DependsOn = "[Script]DomainCertificatesDirectory";
		}

		Script ApplicationGatewayAuthenticationCertificate
		{
			GetScript = {
				$applicationGatewayAuthenticationCertificatePath = "$($using:_domainFilesDirectoryPath)$($using:_domainCertificatesDirectoryName)\Application-Gateway-Authentication-Certificate.pfx";
				$result = $applicationGatewayAuthenticationCertificatePath;

				if(Test-Path $applicationGatewayAuthenticationCertificatePath)
				{
					$result = "$($using:_existsPrefix)$($result)";
				}

				return @{ Result = $result };
			}
			SetScript = {
				$applicationGatewayAuthenticationCertificatePath = (Invoke-Expression -Command $GetScript)["Result"];

				[System.IO.File]::WriteAllBytes($applicationGatewayAuthenticationCertificatePath, [System.Convert]::FromBase64String($using:applicationGatewayAuthenticationCertificateValue));
			}
			TestScript = {
				$result = (Invoke-Expression -Command $GetScript)["Result"];

				if($result -and $result.StartsWith($using:_existsPrefix))
				{
					return $true;
				}

				return $false;
			}
			DependsOn = "[Script]DomainCertificatesDirectory";
		}

		Script ApplicationGatewaySslCertificate
		{
			GetScript = {
				$applicationGatewaySslCertificatePath = "$($using:_domainFilesDirectoryPath)$($using:_domainCertificatesDirectoryName)\Application-Gateway-SSL-Certificate.pfx";
				$result = $applicationGatewaySslCertificatePath;

				if(Test-Path $applicationGatewaySslCertificatePath)
				{
					$result = "$($using:_existsPrefix)$($result)";
				}

				return @{ Result = $result };
			}
			SetScript = {
				$applicationGatewaySslCertificatePath = (Invoke-Expression -Command $GetScript)["Result"];

				[System.IO.File]::WriteAllBytes($applicationGatewaySslCertificatePath, [System.Convert]::FromBase64String($using:applicationGatewaySslCertificateValue));
			}
			TestScript = {
				$result = (Invoke-Expression -Command $GetScript)["Result"];

				if($result -and $result.StartsWith($using:_existsPrefix))
				{
					return $true;
				}

				return $false;
			}
			DependsOn = "[Script]DomainCertificatesDirectory";
		}

		if($serviceAccounts)
		{
			foreach($serviceAccount in $serviceAccounts)
			{
				DomainServiceAccount "ServiceAccount-$($serviceAccount.Name)"
				{
					Credential = $credential;
					Description = $serviceAccount.Description;
					DomainName = $domainName;			
					Name = $serviceAccount.Name;
					ServicePrincipalNames = $serviceAccount.ServicePrincipalNames;
					DependsOn = "[DomainController]DomainController";
				}
			}
		}

		Script Sharing
		{
			GetScript = {
				return @{ Result = "" };
			}
			SetScript = {
				# Temporary
				netsh advfirewall set domain state off;
			}
			TestScript = {
				return $false;
			}
			DependsOn = "[DomainController]DomainController";
		}

		CertificateTrust CertificateTrust
		{
			CertificateNames = "Application-Gateway-Authentication-Certificate", "Application-Gateway-SSL-Certificate";
			Credential = $credential;
			DomainControllerName = $env:ComputerName;
		}

		Chrome Chrome {}
	}
}