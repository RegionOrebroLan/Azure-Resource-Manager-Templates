﻿configuration DomainController
{
	param
	(
		[Parameter(Mandatory)]
		[PSCredential]$credential,
		[Parameter(Mandatory)]
		[string]$dnsServerForwarderIpAddress,
		[Parameter(Mandatory)]
		[string]$dnsServerIpAddress,
		[Parameter(Mandatory)]
		[string]$domainName,
		[Parameter(Mandatory)]
		[string]$ipAddress
	)

	Import-DscResource -Module Parts, PSDesiredStateConfiguration, xActiveDirectory, xDnsServer;

	DomainNameServer "DomainNameServer"
	{
		DnsServerIpAddress = $dnsServerIpAddress;
		IpAddress = $ipAddress;
	}
	
	WindowsFeature "ActiveDirectoryDomainServicesFeature"
	{
		Ensure = "Present";
		Name = "AD-Domain-Services";
		DependsOn = "[DomainNameServer]DomainNameServer";
	}

	WindowsFeature "ActiveDirectoryDomainServicesToolsFeature"
	{
		Ensure = "Present";
		Name = "RSAT-ADDS-Tools";
		DependsOn = "[WindowsFeature]ActiveDirectoryDomainServicesFeature";
	}

	WindowsFeature "ActiveDirectoryAdministrationCenterFeature"
	{
		Ensure = "Present";
		Name = "RSAT-AD-AdminCenter";
		DependsOn = "[WindowsFeature]ActiveDirectoryDomainServicesFeature";
	}

	xADDomain "ActiveDirectoryDomain"
	{
		DomainAdministratorCredential = $credential;
		DomainName = $domainName;
		SafemodeAdministratorPassword = $credential;
		DependsOn = "[WindowsFeature]ActiveDirectoryDomainServicesFeature";
	}

	xDnsServerForwarder "DnsServerForwarder"
	{
		IPAddresses = $dnsServerForwarderIpAddress;
		IsSingleInstance = "Yes";
		DependsOn = "[xADDomain]ActiveDirectoryDomain";
	}
}