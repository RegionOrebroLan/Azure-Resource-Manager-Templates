﻿configuration CertificateServer
{
	param
	(
		[Parameter(Mandatory)]
		[PSCredential]$credential
	)

	Import-DscResource -Module PSDesiredStateConfiguration, xAdcsDeployment;

	# Advanced Certificate Services Configuration with DSC - https://dscottraynsford.wordpress.com/2015/09/03/advanced-certificate-services-configuration-with-dsc/

	WindowsFeature "ActiveDirectoryCertificateServicesAuthorityFeature"
	{
		Ensure = "Present";
		Name = "ADCS-Cert-Authority";
	}

	WindowsFeature "ActiveDirectoryCertificateServicesManagementFeature"
	{
		Ensure = "Present";
		Name = "RSAT-ADCS-Mgmt";
	}

	xADCSCertificationAuthority "ActiveDirectoryCertificateServicesCertificationAuthority"
	{
		Ensure = "Present";
		Credential = $credential;
		CAType = "EnterpriseRootCA";
		DependsOn = "[WindowsFeature]ActiveDirectoryCertificateServicesAuthorityFeature";
	}

	WindowsFeature "ActiveDirectoryCertificateServicesWebEnrollmentFeature"
	{
		Ensure = "Present";
		Name = "ADCS-Web-Enrollment";
		DependsOn = "[WindowsFeature]ActiveDirectoryCertificateServicesAuthorityFeature";
	}

	xADCSWebEnrollment "CertificateServer"
	{
		Ensure = "Present";
		Credential = $credential;
		IsSingleInstance  = "Yes";			
		DependsOn = "[WindowsFeature]ActiveDirectoryCertificateServicesWebEnrollmentFeature","[xADCSCertificationAuthority]ActiveDirectoryCertificateServicesCertificationAuthority";
	}
}