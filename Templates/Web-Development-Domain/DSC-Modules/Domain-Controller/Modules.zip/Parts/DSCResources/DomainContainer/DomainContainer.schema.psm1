﻿configuration DomainContainer
{
	param
	(
		[Parameter(Mandatory)]
		[PSCredential]$credential,
		[string]$description,
		[string]$displayName,
		[Parameter(Mandatory)]
		[string]$domainName,
		[Parameter(Mandatory)]
		[string]$name,
		[Parameter(Mandatory)]
		[string]$parent
	)

	Import-DscResource -Module Parts, PSDesiredStateConfiguration;

	$_existsPrefix = "Exists=True;Result=";
	# We have to copy the value from $name to $containerName here, otherwise the $using:name variable in the SetScript has the value of a Script-resource-name. Don't know why.
	$containerName = $name;
	$distinguishedName = "CN=$($containerName),$($parent)";	

	DomainObjectClassActivation "ContainerActivation"
	{
		Credential = $credential;
		DomainName = $domainName;
		Name = "Container";
	}

	Script "Container"
	{
		GetScript = {
			try
			{
				$domainContainer = Get-ADObject -Identity $using:distinguishedName;

				$result = "$($using:_existsPrefix)$($using:distinguishedName)";
			}
			catch
			{
				$result = $using:parent;
			}

			return @{ Result = $result };
		}
		SetScript = {
			$parent = (Invoke-Expression -Command $GetScript)["Result"];

			try
			{
				New-ADObject -Description $using:description -DisplayName $using:displayName -Name $using:containerName -OtherAttributes @{ "showInAdvancedViewOnly" = $false } -Path $parent -Type "Container";
			}
			catch
			{
				throw "Could not create container ""$($using:containerName)"", parent = ""$($parent)"". -> $($_.Exception.Message)";
			}
		}
		TestScript = {
			$result = (Invoke-Expression -Command $GetScript)["Result"];

			if($result -and $result.StartsWith($using:_existsPrefix))
			{
				return $true;
			}

			return $false;
		}
		DependsOn = "[DomainObjectClassActivation]ContainerActivation";
	}
}