﻿configuration StaticIp
{
	param
	(
		[Parameter(Mandatory)]
		[string]$dnsServerIpAddress,
		[Parameter(Mandatory)]
		[string]$ipAddress
	)

	Import-DscResource -Module PSDesiredStateConfiguration, xNetworking;

	$netIpAddress = Get-NetIPAddress -IPAddress $ipAddress;
	$addressFamily = $netIpAddress.AddressFamily;
	$interfaceAlias = $netIpAddress.InterfaceAlias;
	$netIpConfiguration = Get-NetIPConfiguration -InterfaceAlias $interfaceAlias;
	
	if($addressFamily -eq "IPv4")
	{
		$defaultGateways = $netIpConfiguration.IPv4DefaultGateway;
	}
	else
	{
		$defaultGateways = $netIpConfiguration.IPv6DefaultGateway;
	}
		
	$defaultGateway = $defaultGateways | ForEach { $_.NextHop } | Select -First 1;

	xDhcpClient "DhcpClient"
	{
		AddressFamily = $addressFamily;
		InterfaceAlias = $interfaceAlias;
		State = "Disabled";
	}

	xIPAddress "IPAddress"
	{
		AddressFamily = $addressFamily;
		InterfaceAlias = $interfaceAlias;
		IPAddress = $ipAddress;
	}

	xDefaultGatewayAddress "GatewayAddress"
	{
		Address = $defaultGateway;
		AddressFamily = $addressFamily;
		InterfaceAlias = $interfaceAlias;
	}

	xDnsServerAddress "DnsServerAddress"
	{
		Address = $dnsServerIpAddress;
		AddressFamily = $addressFamily;
		InterfaceAlias = $interfaceAlias;
	}
}