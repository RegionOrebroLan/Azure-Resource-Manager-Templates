﻿configuration DomainObjectClassActivation
{
	param
	(
		[Parameter(Mandatory)]
		[PSCredential]$credential,
		[Parameter(Mandatory)]
		[string]$domainName,
		[bool]$enabled = $true,
		[Parameter(Mandatory)]
		[string]$name
	)

	Import-DscResource -Module PSDesiredStateConfiguration;

	$domainNameParts = $domainName.Split(".");

	for($i = 0; $i -lt $domainNameParts.Count; $i++)
	{
		$domainNameParts[$i] = "DC=$($domainNameParts[$i])";
	}

	$domainDistinguishedName = [string]::Join(",", $domainNameParts);

	$_defaultHidingValueAttributeName = "defaultHidingValue";
	$_existsPrefix = "Exists=True;Result=";
	$schemaDistinguishedName = "CN=Schema,CN=Configuration,$($domainDistinguishedName)";
	$objectClassDistinguishedName = "CN=$($name),$($schemaDistinguishedName)";

	Script "Activation"
	{
		GetScript = {
			$result = $using:objectClassDistinguishedName;

			$objectClass = Get-ADObject -Identity $using:objectClassDistinguishedName -Properties $using:_defaultHidingValueAttributeName;

			$defaultHidingValue = $objectClass.DefaultHidingValue;

			if($defaultHidingValue -ne $null -and $defaultHidingValue -ne $using:enabled)
			{
				$result = "$($using:_existsPrefix)$($result)";
			}

			return @{ Result = $result };
		}
		SetScript = {
			$objectClassDistinguishedName = (Invoke-Expression -Command $GetScript)["Result"];

			try
			{
				Set-ADObject -Identity $objectClassDistinguishedName -Replace @{ $using:_defaultHidingValueAttributeName = !$using:enabled };
			}
			catch
			{
				throw "Could not activate/deactivate object-class ""$($objectClassDistinguishedName)"", enabled = $($using:enabled). -> $($_.Exception.Message)";
			}
		}
		TestScript = {
			$result = (Invoke-Expression -Command $GetScript)["Result"];

			if($result -and $result.StartsWith($using:_existsPrefix))
			{
				return $true;
			}

			return $false;
		}
	}
}