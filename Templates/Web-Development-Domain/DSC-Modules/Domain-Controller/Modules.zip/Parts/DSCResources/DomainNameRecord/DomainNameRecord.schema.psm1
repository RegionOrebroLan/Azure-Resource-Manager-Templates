﻿configuration DomainNameRecord
{
	param
	(
		[Parameter(Mandatory)]
		[string]$domainName,
		[Parameter(Mandatory)]
		[string]$ipAddress,
		[Parameter(Mandatory)]
		[string]$name,
		[string]$type = "ARecord"
	)

	Import-DscResource -Module PSDesiredStateConfiguration, xDnsServer;

	xDnsRecord "DnsRecord"
	{
		Ensure = "Present";
		Name = $name.ToLower();
		Target = $ipAddress;
		Type = $type;
		Zone = $domainName;
	}
}