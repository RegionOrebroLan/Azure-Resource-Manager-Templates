﻿configuration DomainNameServer
{
	param
	(
		[Parameter(Mandatory)]
		[string]$dnsServerIpAddress,
		[Parameter(Mandatory)]
		[string]$ipAddress
	)
	
	Import-DscResource -Module Parts, PSDesiredStateConfiguration;

	StaticIp "StaticIp"
	{
		DnsServerIpAddress = $dnsServerIpAddress;
		IpAddress = $ipAddress;
	}

	WindowsFeature "DomainNameSystemFeature"
	{ 
		Ensure = "Present";
		Name = "DNS";
		DependsOn = "[StaticIp]StaticIp";
	}

	WindowsFeature "DomainNameSystemToolsFeature"
	{
		Ensure = "Present";
		Name = "RSAT-DNS-Server";
		DependsOn = "[WindowsFeature]DomainNameSystemFeature";
	}	
}