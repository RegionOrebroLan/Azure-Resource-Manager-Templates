﻿configuration DomainServiceAccount
{
	param
	(
		[Parameter(Mandatory)]
		[PSCredential]$credential,
		[string]$description,
		[string]$displayName,
		[Parameter(Mandatory)]
		[string]$domainName,
		[Parameter(Mandatory)]
		[string]$name,
		[string[]]$servicePrincipalNames
	)

	Import-DscResource -Module Parts, PSDesiredStateConfiguration;

	$domainNameParts = $domainName.Split(".");

	for($i = 0; $i -lt $domainNameParts.Count; $i++)
	{
		$domainNameParts[$i] = "DC=$($domainNameParts[$i])";
	}

	$domainDistinguishedName = [string]::Join(",", $domainNameParts);

	$_existsPrefix = "Exists=True;Result=";
	$groupContainerName = "Groups";
	$groupContainerDistinguishedName = "CN=$($groupContainerName),$($domainDistinguishedName)";
	$serviceAccountContainerName = "Service-accounts";
	$serviceAccountContainerDistinguishedName = "CN=$($serviceAccountContainerName),$($domainDistinguishedName)";
	# We have to copy the value from $name to $serviceAccountName here, otherwise the $using:name variable in the SetScript has the value of a Script-resource-name. Don't know why.
	$serviceAccountName = $name;
	$serviceGroupName = "Services";

	DomainContainer "GroupContainer"
	{
		Credential = $credential;
		Description = "Default container for groups.";
		DomainName = $domainName;
		Name = $groupContainerName;
		Parent = $domainDistinguishedName;
	}

	DomainContainer "ServiceAccountContainer"
	{
		Credential = $credential;
		Description = "Default container for service accounts.";
		DomainName = $domainName;
		Name = $serviceAccountContainerName;
		Parent = $domainDistinguishedName;
	}

	Script "ServiceGroup"
	{
		GetScript = {
			try
			{
				$serviceGroup = Get-ADGroup -Identity $using:serviceGroupName;

				return @{ Result = "$($using:_existsPrefix)$($serviceGroup.DistinguishedName)" };
			}
			catch
			{
				return @{ Result = "Exists=False" };
			}
		}
		SetScript = {
			try
			{
				New-ADGroup -GroupCategory Security -GroupScope Global -Name $using:serviceGroupName -Path $using:groupContainerDistinguishedName;
			}
			catch
			{
				throw "Could not create group ""$($using:serviceGroupName)"", path = ""$($using:groupContainerDistinguishedName)"". -> $($_.Exception.Message)";
			}
		}
		TestScript = {
			$result = (Invoke-Expression -Command $GetScript)["Result"];

			if($result -and $result.StartsWith($using:_existsPrefix))
			{
				return $true;
			}

			return $false;
		}
		DependsOn = "[DomainContainer]GroupContainer";
	}

	Script "ServiceAccount"
	{
		GetScript = {
			try
			{
				$serviceAccount = Get-ADUser -Identity $using:serviceAccountName;

				return @{ Result = "$($using:_existsPrefix)$($serviceAccount.DistinguishedName)" };
			}
			catch
			{
				return @{ Result = "Exists=False" };
			}
		}
		SetScript = {
			try
			{
				$parameters = New-Object System.Collections.Hashtable;

				if($using:description)
				{
					$parameters.Add("Description", $using:description);
				}

				if($using:displayName)
				{
					$parameters.Add("DisplayName", $using:displayName);
				}

				if($using:servicePrincipalNames -and $using:servicePrincipalNames.Count -gt 0)
				{
					$parameters.Add("ServicePrincipalNames", $using:servicePrincipalNames);
				}

				New-ADUser `
					-AccountPassword $using:credential.Password `
					-Enabled $true `
					-Name $using:serviceAccountName `
					-PasswordNeverExpires $true `
					-Path $using:serviceAccountContainerDistinguishedName `
					-UserPrincipalName "$($using:serviceAccountName)@$($using:domainName)".ToLower() `
					@parameters;

				Add-ADGroupMember -Identity $using:serviceGroupName -Members $using:serviceAccountName;

				$serviceGroupSidValue = (Get-ADGroup $using:serviceGroupName).Sid.Value;

				Get-ADUser $using:serviceAccountName | Set-ADObject -Replace @{ "primaryGroupID" = $serviceGroupSidValue.Substring($serviceGroupSidValue.LastIndexOf("-") + 1) }

				Remove-ADGroupMember -Confirm:$false -Identity "Domain Users" -Members $using:serviceAccountName;
			}
			catch
			{
				throw "Could not create service-account ""$($using:serviceAccountName)"", path = ""$($using:serviceAccountContainerDistinguishedName)"". -> $($_.Exception.Message)";
			}
		}
		TestScript = {
			$result = (Invoke-Expression -Command $GetScript)["Result"];

			if($result -and $result.StartsWith($using:_existsPrefix))
			{
				return $true;
			}

			return $false;
		}
		DependsOn = "[DomainContainer]ServiceAccountContainer", "[Script]ServiceGroup";
	}
}