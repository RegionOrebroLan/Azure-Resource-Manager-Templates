﻿configuration AdfsConfiguration
{
	param
	(
		[Parameter(Mandatory)]
		[PSCredential]$credential,
		[Parameter(Mandatory)]
		[string]$databaseServerName,
		[Parameter(Mandatory)]
		[string]$domainControllerName,
		[Parameter(Mandatory)]
		[string]$domainName,
		[Parameter(Mandatory)]
		[string]$serviceAccount
	)

	Import-DscResource -Module Parts, PSDesiredStateConfiguration;

	node localhost
	{
		LocalConfigurationManager
		{
			RebootNodeIfNeeded = $true;
		}
	
		DomainComputer DomainComputer
		{
			Credential = $credential;
			DomainName = $domainName;
		}
	
		ADFS ADFS
		{
			Credential = $credential;
			DatabaseServerName = $databaseServerName;
			DomainControllerName = $domainControllerName;
			DomainName = $domainName;
			ServiceAccount = $serviceAccount;
		}

		CertificateTrust CertificateTrust
		{
			CertificateNames = "Application-Gateway-Authentication-Certificate", "Application-Gateway-SSL-Certificate";
			Credential = $credential;
			DomainControllerName = $domainControllerName;
		}

		Chrome Chrome {}
	}
}