﻿configuration ADFS
{
	param
	(
		[Parameter(Mandatory)]
		[PSCredential]$credential,
		[Parameter(Mandatory)]
		[string]$databaseServerName,
		[Parameter(Mandatory)]
		[string]$domainControllerName,
		[Parameter(Mandatory)]
		[string]$domainName,
		[Parameter(Mandatory)]
		[string]$serviceAccount
	)

	Import-DscResource -Module PSDesiredStateConfiguration;

	$_existsPrefix = "Exists=True;Result=";

	WindowsFeature "ActiveDirectoryFederationServicesFeature"
	{
		Ensure = "Present";
		Name = "ADFS-Federation";
	}

	# https://docs.microsoft.com/en-us/powershell/module/adfs/install-adfsfarm?view=win10-ps
	# https://technet.microsoft.com/sv-se/library/dn469336.aspx?f=255&MSPPError=-2147217396

	Script "Install"
	{
		GetScript = {
			try
			{
				$adfsProperties = Get-ADFSProperties;

				return @{ Result = "$($using:_existsPrefix)$($adfsProperties.HostName)" };
			}
			catch
			{
				return @{ Result = "Exists=False" };
			}
		}
		SetScript = {
			$adfsCertificate = Import-PfxCertificate -CertStoreLocation "Cert:\LocalMachine\My" -FilePath "\\$($using:domainControllerName)\Domain-Files\Certificates\ADFS-Certificate.pfx" -Password $using:credential.Password;

			$serviceAccountCredential = New-Object System.Management.Automation.PSCredential($using:serviceAccount, $using:credential.Password);

			Install-AdfsFarm `
				-CertificateThumbprint $adfsCertificate.Thumbprint `
				-Credential $using:credential `
				-FederationServiceDisplayName "Active Directory Federation Service" `
				-FederationServiceName "adfs.$($using:domainName)" `
				-ServiceAccountCredential $serviceAccountCredential `
				-SQLConnectionString "Server=$($using:databaseServerName);Integrated Security=True" `
				-OverwriteConfiguration;

			#$global:DSCMachineStatus = 1; # Trigger a reboot if necessary.
		}
		TestScript = {
			$result = (Invoke-Expression -Command $GetScript)["Result"];

			if($result -and $result.StartsWith($using:_existsPrefix))
			{
				return $true;
			}

			return $false;
		}
		DependsOn = "[WindowsFeature]ActiveDirectoryFederationServicesFeature";
	}
}