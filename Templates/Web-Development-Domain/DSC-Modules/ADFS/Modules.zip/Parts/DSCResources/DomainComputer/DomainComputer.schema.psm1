﻿configuration DomainComputer
{
	param
	(
		[Parameter(Mandatory)]
		[PSCredential]$credential,
		[Parameter(Mandatory)]
		[string]$domainName
	)

	Import-DscResource -Module Parts, PSDesiredStateConfiguration, xActiveDirectory, xComputerManagement;

	xWaitForADDomain "WaitForDomain"
	{
		DomainName = $domainName;
		DomainUserCredential = $credential;
		RetryCount = 20;
		RetryIntervalSec = 30;
	}

	xComputer "JoinDomain"
	{
		Credential = $credential;
		DomainName = $domainName;
		Name = $env:ComputerName;
		DependsOn = "[xWaitForADDomain]WaitForDomain";
	}

	Sharing Sharing
	{
		DependsOn = "[xComputer]JoinDomain";
	}
}