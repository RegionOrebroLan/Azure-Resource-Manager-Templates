﻿configuration Sharing
{
	Import-DscResource -Module PSDesiredStateConfiguration;

	Script Sharing
	{
		GetScript = {
			return @{ Result = "" };
		}
		SetScript = {
			$names = New-Object System.Collections.Generic.List[string];

			$names.Add("File and Printer Sharing (Echo Request - ICMPv4-In)");
			$names.Add("File and Printer Sharing (Echo Request - ICMPv4-Out)");
			$names.Add("File and Printer Sharing (Echo Request - ICMPv6-In)");
			$names.Add("File and Printer Sharing (Echo Request - ICMPv6-Out)");
			$names.Add("File and Printer Sharing (LLMNR-UDP-In)");
			$names.Add("File and Printer Sharing (LLMNR-UDP-Out)");
			$names.Add("File and Printer Sharing (NB-Datagram-In)");
			$names.Add("File and Printer Sharing (NB-Datagram-Out)");
			$names.Add("File and Printer Sharing (NB-Name-In)");
			$names.Add("File and Printer Sharing (NB-Name-Out)");
			$names.Add("File and Printer Sharing (NB-Session-In)");
			$names.Add("File and Printer Sharing (NB-Session-Out)");
			$names.Add("File and Printer Sharing (SMB-In)");
			$names.Add("File and Printer Sharing (SMB-Out)");
			$names.Add("File and Printer Sharing (Spooler Service - RPC)");
			$names.Add("File and Printer Sharing (Spooler Service - RPC-EPMAP)");

			$names.Add("Network Discovery (LLMNR-UDP-In)");
			$names.Add("Network Discovery (LLMNR-UDP-Out)");
			$names.Add("Network Discovery (NB-Datagram-In)");
			$names.Add("Network Discovery (NB-Datagram-Out)");
			$names.Add("Network Discovery (NB-Name-In)");
			$names.Add("Network Discovery (NB-Name-Out)");
			$names.Add("Network Discovery (Pub WSD-Out)");
			$names.Add("Network Discovery (Pub-WSD-In)");
			$names.Add("Network Discovery (SSDP-In)");
			$names.Add("Network Discovery (SSDP-Out)");
			$names.Add("Network Discovery (UPnPHost-Out)");
			$names.Add("Network Discovery (UPnP-In)");
			$names.Add("Network Discovery (UPnP-Out)");
			$names.Add("Network Discovery (WSD Events-In)");
			$names.Add("Network Discovery (WSD Events-Out)");
			$names.Add("Network Discovery (WSD EventsSecure-In)");
			$names.Add("Network Discovery (WSD EventsSecure-Out)");
			$names.Add("Network Discovery (WSD-In)");
			$names.Add("Network Discovery (WSD-Out)");

			foreach($name in $names)
			{
				netsh advfirewall firewall set rule name=$name profile=domain new enable=yes;
			}

			# Temporary
			netsh advfirewall set domain state off;
		}
		TestScript = {
			return $false;
		}
	}
}